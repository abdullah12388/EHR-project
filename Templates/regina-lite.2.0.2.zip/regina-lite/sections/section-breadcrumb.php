<?php
/**
 *  The template for displaying the Section: Breadcrumbs.
 *
 *  @package regina-lite
 */
?>
<div class="col-xs-12">
	<?php do_action( 'mtl_breadcrumbs' ); ?>
</div><!--.col-xs-12-->
