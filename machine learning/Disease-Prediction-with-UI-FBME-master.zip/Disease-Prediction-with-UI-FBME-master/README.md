A simple machine learning program that I made within a few days during the first week of my 3-month machine learning challenge.

![alt text]( screenshot/Disease-Prediciton-program.jpg "oldschool-ui-design-for-machine-learning-program")
