from tkinter import *
import numpy as np

import pickle
filename = 'trained_model/breast-cancer.sav'
loaded_model = pickle.load(open(filename, 'rb'))

filename = 'trained_model/heart-disease.sav'
loaded_model2 = pickle.load(open(filename, 'rb'))

filename = 'trained_model/dermatology.sav'
loaded_model3 = pickle.load(open(filename, 'rb'))

filename = 'trained_model/ckd.sav'
loaded_model4 = pickle.load(open(filename,'rb'))

class Page(Frame):
	def __init__(self, *args, **kwargs):
		Frame.__init__(self, *args, **kwargs)
	def show(self):
		self.lift()

class Page1(Page):
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs)
		
		#==============
		# all StringVar()
		#==============
		ClumpThickness = StringVar()
		UniformityofCellSize = StringVar()
		UniformityofCellShape = StringVar()
		MarginalAdhesion = StringVar()
		SingleEpithelialCellSize = StringVar()
		BareNuclei = StringVar()
		BlandChromatin = StringVar()
		NormalNucleoli = StringVar()
		Mitoses = StringVar()
		
		ClumpThickness.set("")
		UniformityofCellSize.set("")
		UniformityofCellShape.set("")
		MarginalAdhesion.set("")
		SingleEpithelialCellSize.set("")
		BareNuclei.set("")
		BlandChromatin.set("")
		NormalNucleoli.set("")
		Mitoses.set("")
		
		#=============
		# main layout
		#=============
		Tops = Frame(self, width=1366, height=40, bd=1,relief=RIDGE)
		Tops.pack(side=TOP)
		
		lblInfo=Label(Tops, font=('arial',20,'bold'),bg='purple',fg='white',text ="Breast Cancer Prediction", bd=5,anchor='w')
		lblInfo.grid(row=0,column=0)
		
		
		
		fs1 = Frame(self,width=150, height=0, bd=1,relief='flat')
		fs1.pack(side=LEFT)
		
		f1 = Frame(self, width=600, height=600, bd=8,relief='raise')
		f1.pack(side=LEFT)
		
		f2 = Frame(self, width=366, height=600, bd=8,relief='raise')
		f2.pack(side=LEFT)
		
		#for description
		f3 = Frame(f2, width=1000, height=320, bd=8,relief=FLAT)
		f3.pack(side=BOTTOM)
		
		f2ab = Frame(f2, width=366, height=300,bd=8,relief='raise')
		f2ab.pack(side=BOTTOM)
		
		f2a = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2a.pack(side=BOTTOM)
		
		f2aa = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2aa.pack(side=BOTTOM)
		
		#===============
		# some displays
		#===============
		text = 'NOTE:\nAccuracy of prediction: 94%\n'
		lbldetails = Label(f3,font=('Courier',12),text=text,bd=16,justify='left')
		lbldetails.grid(row=0,column=0)
		
		#============
		#  Inputs
		#=============
		lblClumpThickness = Label(f1,font=('arial',16,'bold'),text='Clump Thickness',bd=16,justify='left')
		lblClumpThickness.grid(row=0,column=0)
		txtClumpThickness=Entry(f1,font=('arial',16,'bold'),textvariable=ClumpThickness,bd=10,insertwidth=2,justify='left')
		txtClumpThickness.grid(row=0,column=1)
		
		
		lblUniformityofCellSize = Label(f1,font=('arial',16,'bold'),text='Uniformity of Cell Size',bd=16,justify='left')
		lblUniformityofCellSize.grid(row=1,column=0)
		txtUniformityofCellSize=Entry(f1,font=('arial',16,'bold'),textvariable=UniformityofCellSize,bd=10,insertwidth=2,justify='left')
		txtUniformityofCellSize.grid(row=1,column=1)
		
		lblUniformityofCellShape = Label(f1,font=('arial',16,'bold'),text='Uniformity of Cell Shape',bd=16,justify='left')
		lblUniformityofCellShape.grid(row=2,column=0)
		txtUniformityofCellShape=Entry(f1,font=('arial',16,'bold'),textvariable=UniformityofCellShape,bd=10,insertwidth=2,justify='left')
		txtUniformityofCellShape.grid(row=2,column=1)
		
		lblMarginalAdhesion = Label(f1,font=('arial',16,'bold'),text='Marginal Adhesion',bd=16,justify='left')
		lblMarginalAdhesion.grid(row=3,column=0)
		txtMarginalAdhesion=Entry(f1,font=('arial',16,'bold'),textvariable=MarginalAdhesion,bd=10,insertwidth=2,justify='left')
		txtMarginalAdhesion.grid(row=3,column=1)
		
		lblSingleEpithelialCellSize = Label(f1,font=('arial',16,'bold'),text='Single Epithelial Cell Size',bd=16,justify='left')
		lblSingleEpithelialCellSize.grid(row=4,column=0)
		txtSingleEpithelialCellSize=Entry(f1,font=('arial',16,'bold'),textvariable=SingleEpithelialCellSize,bd=10,insertwidth=2,justify='left')
		txtSingleEpithelialCellSize.grid(row=4,column=1)
		
		lblBareNuclei = Label(f1,font=('arial',16,'bold'),text='Bare Nuclei',bd=16,justify='left')
		lblBareNuclei.grid(row=5,column=0)
		txtBareNuclei=Entry(f1,font=('arial',16,'bold'),textvariable=BareNuclei,bd=10,insertwidth=2,justify='left')
		txtBareNuclei.grid(row=5,column=1)
		
		lblBlandChromatin = Label(f1,font=('arial',16,'bold'),text='Bland Chromatin',bd=16,justify='left')
		lblBlandChromatin.grid(row=6,column=0)
		txtBlandChromatin=Entry(f1,font=('arial',16,'bold'),textvariable=BlandChromatin,bd=10,insertwidth=2,justify='left')
		txtBlandChromatin.grid(row=6,column=1)
		
		lblNormalNucleoli = Label(f1,font=('arial',16,'bold'),text='Normal Nucleoli',bd=16,justify='left')
		lblNormalNucleoli.grid(row=7,column=0)
		txtNormalNucleoli=Entry(f1,font=('arial',16,'bold'),textvariable=NormalNucleoli,bd=10,insertwidth=2,justify='left')
		txtNormalNucleoli.grid(row=7,column=1)
		
		lblMitoses = Label(f1,font=('arial',16,'bold'),text='Mitoses',bd=16,justify='left')
		lblMitoses.grid(row=8,column=0)
		txtMitoses=Entry(f1,font=('arial',16,'bold'),textvariable=Mitoses,bd=10,insertwidth=2,justify='left')
		txtMitoses.grid(row=8,column=1)
		
		#================
		#    Outputs
		#================
		Result = StringVar()
		lblResult = Label(f2a,font=('arial',16,'bold'),text='Result',bd=16,anchor='w')
		lblResult.grid(row=0,column=0)
		txtResult=Entry(f2a,font=('arial',16,'bold'),textvariable=Result,bd=10,insertwidth=2,justify='left')
		txtResult.grid(row=0,column=1)
		
		def getData():
			alist = []
			ClumpThickness_data = int(ClumpThickness.get())
			alist.append(ClumpThickness_data)
			UniformityofCellSize_data = int(UniformityofCellSize.get())
			alist.append(UniformityofCellSize_data)
			UniformityofCellShape_data = int(UniformityofCellShape.get())
			alist.append(UniformityofCellShape_data)
			MarginalAdhesion_data = int(MarginalAdhesion.get())
			alist.append(MarginalAdhesion_data)
			SingleEpithelialCellSize_data = int(SingleEpithelialCellSize.get())
			alist.append(MarginalAdhesion_data)
			BareNuclei_data = int(BareNuclei.get())
			alist.append(BareNuclei_data)
			BlandChromatin_data = int(BlandChromatin.get())
			alist.append(BlandChromatin_data)
			NormalNucleoli_data = int(NormalNucleoli.get())
			alist.append(NormalNucleoli_data)
			Mitoses_data = int(Mitoses.get())
			alist.append(Mitoses_data)
			return alist
			
		def printResult():
			try:
				x_in=getData()
			except ValueError:
				Result.set('Insufficient Data!')
			else:
				x_in = np.reshape(getData(),(1,9))
				result = loaded_model.predict(x_in)
				result = result[0]
				if result == 2.0:
					Result.set('Benign')
				else:
					Result.set('MAGLINANT!')		
		
		def Reset():
			ClumpThickness.set("")
			UniformityofCellSize.set("")
			UniformityofCellShape.set("")
			MarginalAdhesion.set("")
			SingleEpithelialCellSize.set("")
			BareNuclei.set("")
			BlandChromatin.set("")
			NormalNucleoli.set("")
			Mitoses.set("")
			Result.set("")
			
		btnTotal=Button(f2aa,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Predict', command = printResult).grid(row=0,column=0)
		btnReset=Button(f2ab,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Reset', command = Reset).grid(row=0,column=0)

class Page2(Page):
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs)
		#~ label = Label(self, text="This is the page 2")
		#~ label.pack(side=TOP, fill='both', expand=True)
		Tops = Frame(self, width=1366, height=40, bd=1,relief=RIDGE)
		Tops.pack(side=TOP)
		
		lblInfo=Label(Tops, font=('arial',20,'bold'),bg='red',fg='white',text ="Heart Disease Prediciton", bd=5,anchor='w')
		lblInfo.grid(row=0,column=0)
		
		fs1 = Frame(self,width=150, height=0, bd=1,relief='flat')
		fs1.pack(side=LEFT)
		
		f1 = Frame(self, width=600, height=600, bd=8,relief='raise')
		f1.pack(side=LEFT)
		
		f2 = Frame(self, width=366, height=600, bd=8,relief='raise')
		f2.pack(side=LEFT)
		
		#for description
		f3 = Frame(f2, width=1000, height=320, bd=8,relief=FLAT)
		f3.pack(side=BOTTOM)
		
		f2ab = Frame(f2, width=366, height=300,bd=8,relief='raise')
		f2ab.pack(side=BOTTOM)
		
		f2a = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2a.pack(side=BOTTOM)
		
		f2aa = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2aa.pack(side=BOTTOM)
		
		#===============
		# some displays
		#===============
		text = 'NOTE:\nAccuracy of prediction: 74%\n'
		lbldetails = Label(f3,font=('Courier',12),text=text,bd=16,justify='left')
		lbldetails.grid(row=0,column=0)
		
		#=====================
		# All StringVar()
		#=====================
		Age = StringVar()
		Sex = StringVar()
		ChestPainType = StringVar()
		RestingBloodPressure = StringVar()
		Chol = StringVar()
		FBS = StringVar()
		RestECG = StringVar()
		Thalach = StringVar()
		ExAng = StringVar()
		OldPeak = StringVar()
		Slope = StringVar()
		MajVess = StringVar()
		Thal = StringVar()
		#============
		#  Inputs
		#=============
		txtsize = 11
		bdsize = 10
		entrysize = 13
		entrybdsize = 10
		
		lblAge = Label(f1,font=('arial',txtsize,'bold'),text='Age',bd=bdsize,justify='left')
		lblAge.grid(row=0,column=0)
		txtAge=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Age,bd=entrybdsize,insertwidth=2,justify='left')
		txtAge.grid(row=0,column=1)
		
		lblSex = Label(f1,font=('arial',txtsize,'bold'),text='Sex(M-1, F-0)',bd=bdsize,justify='left')
		lblSex.grid(row=1,column=0)
		txtSex=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Sex,bd=entrybdsize,insertwidth=2,justify='left')
		txtSex.grid(row=1,column=1)
		
		lblChestPainType = Label(f1,font=('arial',txtsize,'bold'),text='Chest Pain Type(typical-1, atypical-2,\nnon-anginal-3, asymptomatic-4)',bd=bdsize,justify='left')
		lblChestPainType.grid(row=2,column=0)
		txtChestPainType=Entry(f1,font=('arial',entrysize,'bold'),textvariable=ChestPainType,bd=entrybdsize,insertwidth=2,justify='left')
		txtChestPainType.grid(row=2,column=1)
		
		lblRestingBloodPressure = Label(f1,font=('arial',txtsize,'bold'),text='Resting BP (mm Hg)',bd=bdsize,justify='left')
		lblRestingBloodPressure.grid(row=3,column=0)
		txtRestingBloodPressure=Entry(f1,font=('arial',entrysize,'bold'),textvariable=RestingBloodPressure,bd=entrybdsize,insertwidth=2,justify='left')
		txtRestingBloodPressure.grid(row=3,column=1)
		
		lblChol = Label(f1,font=('arial',txtsize,'bold'),text='Serum cholestoral (mg/dl)',bd=bdsize,justify='left')
		lblChol.grid(row=4,column=0)
		txtChol=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Chol,bd=entrybdsize,insertwidth=2,justify='left')
		txtChol.grid(row=4,column=1)
		
		lblFBS= Label(f1,font=('arial',txtsize,'bold'),text='Fasting Blood Sugar\n(1 if > 120 mg/dl, else 0)',bd=bdsize,justify='left')
		lblFBS.grid(row=5,column=0)
		txtFBS=Entry(f1,font=('arial',entrysize,'bold'),textvariable=FBS,bd=entrybdsize,insertwidth=2,justify='left')
		txtFBS.grid(row=5,column=1)
		
		lblRestECG= Label(f1,font=('arial',txtsize,'bold'),text='Resting ECG (normal-0, ST-T wave abnormality-1,\ndefinite left ventricular hypertrophy-2)',bd=bdsize,justify='left')
		lblRestECG.grid(row=6,column=0)
		txtRestECG=Entry(f1,font=('arial',entrysize,'bold'),textvariable=RestECG,bd=entrybdsize,insertwidth=2,justify='left')
		txtRestECG.grid(row=6,column=1)
		
		lblThalach= Label(f1,font=('arial',txtsize,'bold'),text='Thalach',bd=bdsize,justify='left')
		lblThalach.grid(row=7,column=0)
		txtThalach=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Thalach,bd=entrybdsize,insertwidth=2,justify='left')
		txtThalach.grid(row=7,column=1)
		
		lblExAng= Label(f1,font=('arial',txtsize,'bold'),text='Exercise induced angina (yes-1, no-0)',bd=bdsize,justify='left')
		lblExAng.grid(row=8,column=0)
		txtExAng=Entry(f1,font=('arial',entrysize,'bold'),textvariable=ExAng,bd=entrybdsize,insertwidth=2,justify='left')
		txtExAng.grid(row=8,column=1)
		
		lblOldPeak= Label(f1,font=('arial',txtsize,'bold'),text='Old peak',bd=bdsize,justify='left')
		lblOldPeak.grid(row=9,column=0)
		txtOldPeak=Entry(f1,font=('arial',entrysize,'bold'),textvariable=OldPeak,bd=entrybdsize,insertwidth=2,justify='left')
		txtOldPeak.grid(row=9,column=1)
		
		lblSlope= Label(f1,font=('arial',txtsize,'bold'),text='Slope (upsloping-1,\n flat-2, downsloping-3)',bd=bdsize,justify='left')
		lblSlope.grid(row=10,column=0)
		txtSlope=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Slope,bd=entrybdsize,insertwidth=2,justify='left')
		txtSlope.grid(row=10,column=1)
		
		lblMajVess= Label(f1,font=('arial',txtsize,'bold'),text='Number of major vessels',bd=bdsize,justify='left')
		lblMajVess.grid(row=11,column=0)
		txtMajVess=Entry(f1,font=('arial',entrysize,'bold'),textvariable=MajVess,bd=entrybdsize,insertwidth=2,justify='left')
		txtMajVess.grid(row=11,column=1)
		
		lblThal= Label(f1,font=('arial',txtsize,'bold'),text='Thal (normal-3, irreversible-6, reversible-7)',bd=bdsize,justify='left')
		lblThal.grid(row=12,column=0)
		txtThal=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Thal,bd=entrybdsize,insertwidth=2,justify='left')
		txtThal.grid(row=12,column=1)
		
		#================
		#    Outputs
		#================
		Result = StringVar()
		lblResult = Label(f2a,font=('arial',16,'bold'),text='Result',bd=16,anchor='w')
		lblResult.grid(row=0,column=0)
		txtResult=Entry(f2a,font=('arial',16,'bold'),textvariable=Result,bd=10,insertwidth=2,justify='left')
		txtResult.grid(row=0,column=1)
		
		def getData():
			alist = []
			Age_data = int(Age.get())
			alist.append(Age_data)
			Sex_data = int(Sex.get())
			alist.append(Sex_data)
			ChestPainType_data = int(ChestPainType.get())
			alist.append(ChestPainType_data)
			RestingBloodPressure_data = int(RestingBloodPressure.get())
			alist.append(RestingBloodPressure_data)
			Chol_data = int(Chol.get())
			alist.append(Chol_data)
			FBS_data = int(FBS.get())
			alist.append(FBS_data)
			RestECG_data = int(RestECG.get())
			alist.append(RestECG_data)
			Thalach_data = int(Thalach.get())
			alist.append(Thalach_data)
			ExAng_data = int(ExAng.get())
			alist.append(ExAng_data)
			OldPeak_data = float(OldPeak.get())
			alist.append(OldPeak_data)
			Slope_data = int(Slope.get())
			alist.append(Slope_data)
			MajVess_data = int(MajVess.get())
			alist.append(MajVess_data)
			Thal_data = int(Thal.get())
			alist.append(Thal_data)
			return alist
			
		def printResult():
			Result.set("")
			try:
				x_in=getData()
			except ValueError:
				Result.set('Insufficient Data!')
			else:
				x_in = np.reshape(getData(),(1,13))
				result = loaded_model2.predict(x_in)
				result = result[0]
				if (int(result)) == 0:
					Result.set('<50% diameter narrowing')
				else:
					Result.set('>50% diameter narrowing')		
		
		def Reset():
			Age.set("")
			Sex.set("")
			ChestPainType.set("")
			RestingBloodPressure.set("")
			Chol.set("")
			FBS.set("")
			RestECG.set("")
			Thalach.set("")
			ExAng.set("")
			OldPeak.set("")
			Slope.set("")
			MajVess.set("")
			Thal.set("")
			Result.set("")
			
		btnTotal=Button(f2aa,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Predict', command = printResult).grid(row=0,column=0)
		btnReset=Button(f2ab,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Reset', command = Reset).grid(row=0,column=0)

class Page3(Page):
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs)
		#~ label = Label(self, text="This is the page 3")
		#~ label.pack(side=TOP, fill='both', expand=True)
		Tops = Frame(self, width=1366, height=40, bd=1,relief=RIDGE)
		Tops.pack(side=TOP)
		
		lblInfo=Label(Tops, font=('arial',20,'bold'),bg='blue',fg='white',text ="Erythemato-squamous Diseases Prediciton", bd=5,anchor='w')
		lblInfo.grid(row=0,column=0)
		
		fs1 = Frame(self,width=150, height=0, bd=1,relief='flat')
		fs1.pack(side=LEFT)
		
		f1 = Frame(self, width=600, height=600, bd=8,relief='raise')
		f1.pack(side=LEFT)
		
		f2 = Frame(self, width=366, height=600, bd=8,relief='raise')
		f2.pack(side=LEFT)
		
		#for description
		f3 = Frame(f2, width=1000, height=320, bd=8,relief=FLAT)
		f3.pack(side=BOTTOM)
		
		f2ab = Frame(f2, width=366, height=300,bd=8,relief='raise')
		f2ab.pack(side=BOTTOM)
		
		f2a = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2a.pack(side=BOTTOM)
		
		f2aa = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2aa.pack(side=BOTTOM)
		
		#===============
		# some displays
		#===============
		text = 'NOTE:\nAccuracy of prediction: 80%\ntake values 1-4 unless otherwise stated'
		lbldetails = Label(f3,font=('Courier',12),text=text,bd=16,justify='left')
		lbldetails.grid(row=0,column=0)
		
		#=====================
		# All StringVar()
		#=====================
		Erythema=StringVar()
		Scaling=StringVar()
		DefiniteBorders=StringVar()
		Itching=StringVar()
		Koebner=StringVar()
		Polygonal=StringVar()
		Follicular=StringVar()
		OralMucosal=StringVar()
		KneeElbow=StringVar()
		Scalp=StringVar()
		FamilyHistory=StringVar()
		Age=StringVar()
		
		#============
		#  Inputs
		#=============
		txtsize = 14
		bdsize = 12
		entrysize = 12
		entrybdsize = 12
		
		lblErythema = Label(f1,font=('arial',txtsize,'bold'),text='Erythema',bd=bdsize,justify='left')
		lblErythema.grid(row=0,column=0)
		txtErythema=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Erythema,bd=entrybdsize,insertwidth=2,justify='left')
		txtErythema.grid(row=0,column=1)
		
		lblScaling = Label(f1,font=('arial',txtsize,'bold'),text='Scaling',bd=bdsize,justify='left')
		lblScaling.grid(row=1,column=0)
		txtScaling=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Scaling,bd=entrybdsize,insertwidth=2,justify='left')
		txtScaling.grid(row=1,column=1)
		
		lblDefiniteBorders = Label(f1,font=('arial',txtsize,'bold'),text='Definite borders',bd=bdsize,justify='left')
		lblDefiniteBorders.grid(row=2,column=0)
		txtDefiniteBorders=Entry(f1,font=('arial',entrysize,'bold'),textvariable=DefiniteBorders,bd=entrybdsize,insertwidth=2,justify='left')
		txtDefiniteBorders.grid(row=2,column=1)
		
		lblItching = Label(f1,font=('arial',txtsize,'bold'),text='Itching',bd=bdsize,justify='left')
		lblItching.grid(row=3,column=0)
		txtItching=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Itching,bd=entrybdsize,insertwidth=2,justify='left')
		txtItching.grid(row=3,column=1)
		
		lblKoebner = Label(f1,font=('arial',txtsize,'bold'),text='Koebner phenomenon',bd=bdsize,justify='left')
		lblKoebner.grid(row=4,column=0)
		txtKoebner=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Koebner,bd=entrybdsize,insertwidth=2,justify='left')
		txtKoebner.grid(row=4,column=1)
		
		lblPolygonal = Label(f1,font=('arial',txtsize,'bold'),text='Polygonal papules',bd=bdsize,justify='left')
		lblPolygonal.grid(row=5,column=0)
		txtPolygonal=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Polygonal,bd=entrybdsize,insertwidth=2,justify='left')
		txtPolygonal.grid(row=5,column=1)
		
		lblFollicular = Label(f1,font=('arial',txtsize,'bold'),text='Follicular papules',bd=bdsize,justify='left')
		lblFollicular.grid(row=6,column=0)
		txtFollicular=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Follicular,bd=entrybdsize,insertwidth=2,justify='left')
		txtFollicular.grid(row=6,column=1)
		
		lblOralMucosal = Label(f1,font=('arial',txtsize,'bold'),text='Oral Mucosal involvement',bd=bdsize,justify='left')
		lblOralMucosal.grid(row=7,column=0)
		txtOralMucosal=Entry(f1,font=('arial',entrysize,'bold'),textvariable=OralMucosal,bd=entrybdsize,insertwidth=2,justify='left')
		txtOralMucosal.grid(row=7,column=1)
		
		lblKneeElbow = Label(f1,font=('arial',txtsize,'bold'),text='Knee & Elbow involvement',bd=bdsize,justify='left')
		lblKneeElbow.grid(row=8,column=0)
		txtKneeElbow=Entry(f1,font=('arial',entrysize,'bold'),textvariable=KneeElbow,bd=entrybdsize,insertwidth=2,justify='left')
		txtKneeElbow.grid(row=8,column=1)
		
		lblScalp = Label(f1,font=('arial',txtsize,'bold'),text='Scalp involvement',bd=bdsize,justify='left')
		lblScalp.grid(row=9,column=0)
		txtScalp=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Scalp,bd=entrybdsize,insertwidth=2,justify='left')
		txtScalp.grid(row=9,column=1)
		
		lblFamilyHistory = Label(f1,font=('arial',txtsize,'bold'),text='Family History (1 or 0)',bd=bdsize,justify='left')
		lblFamilyHistory.grid(row=10,column=0)
		txtFamilyHistory=Entry(f1,font=('arial',entrysize,'bold'),textvariable=FamilyHistory,bd=entrybdsize,insertwidth=2,justify='left')
		txtFamilyHistory.grid(row=10,column=1)
		
		lblAge = Label(f1,font=('arial',txtsize,'bold'),text='Age',bd=bdsize,justify='left')
		lblAge.grid(row=11,column=0)
		txtAge=Entry(f1,font=('arial',entrysize,'bold'),textvariable=Age,bd=entrybdsize,insertwidth=2,justify='left')
		txtAge.grid(row=11,column=1)
		
		#================
		#    Outputs
		#================
		Result = StringVar()
		lblResult = Label(f2a,font=('arial',16,'bold'),text='Result',bd=16,anchor='w')
		lblResult.grid(row=0,column=0)
		txtResult=Entry(f2a,font=('arial',16,'bold'),textvariable=Result,bd=10,insertwidth=2,justify='left')
		txtResult.grid(row=0,column=1)
		
		def getData():
			alist = []
			Erythema_data = int(Erythema.get())
			alist.append(Erythema_data)
			Scaling_data = int(Scaling.get())
			alist.append(Scaling_data)
			DefiniteBorders_data = int(DefiniteBorders.get())
			alist.append(DefiniteBorders_data)
			Itching_data = int(Itching.get())
			alist.append(Itching_data)
			Koebner_data = int(Koebner.get())
			alist.append(Koebner_data)
			Polygonal_data = int(Polygonal.get())
			alist.append(Polygonal_data)
			Follicular_data = int(Follicular.get())
			alist.append(Follicular_data)
			OralMucosal_data = int(OralMucosal.get())
			alist.append(OralMucosal_data)
			KneeElbow_data = int(KneeElbow.get())
			alist.append(KneeElbow_data)
			Scalp_data = float(Scalp.get())
			alist.append(Scalp_data)
			FamilyHistory_data = int(FamilyHistory.get())
			alist.append(FamilyHistory_data)
			Age_data = int(Age.get())
			alist.append(Age_data)
			return alist
			
		def printResult():
			Result.set("")
			try:
				x_in=getData()
			except ValueError:
				Result.set('Insufficient Data!')
			else:
				x_in = np.reshape(getData(),(1,12))
				result = loaded_model3.predict(x_in)
				result = result[0]
				if (int(result)) == 1:
					Result.set('Psoriasis')
				elif (int(result)) == 2:
					Result.set('Seborrheic Dermatitis')
				elif (int(result)) == 3:
					Result.set('Lichen Planus')
				elif (int(result)) == 4:
					Result.set('Pityriasis Rosea')
				elif (int(result)) == 5:
					Result.set('Cronic Dermatitis')
				else:
					Result.set('Pityriasis Rubra Pilaris')		
		
		def Reset():
			Erythema.set("")
			Scaling.set("")
			DefiniteBorders.set("")
			Itching.set("")
			Koebner.set("")
			Polygonal.set("")
			Follicular.set("")
			OralMucosal.set("")
			KneeElbow.set("")
			Scalp.set("")
			FamilyHistory.set("")
			Age.set("")
			Result.set("")
			
		btnTotal=Button(f2aa,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Predict', command = printResult).grid(row=0,column=0)
		btnReset=Button(f2ab,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Reset', command = Reset).grid(row=0,column=0)

class Page4(Page):
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs)
		#~ label = Label(self, text="This is the page 4")
		#~ label.pack(side=TOP, fill='both', expand=True)
		#==============
		# all StringVar()
		#==============
		Age = StringVar()
		BP = StringVar()
		SG = StringVar()
		Alb = StringVar()
		Bgr = StringVar()
		Bu = StringVar()
		Sc = StringVar()
		Sod = StringVar()
		Pot = StringVar()
		Hemo = StringVar()
		
		Age.set("")
		BP.set("")
		SG.set("")
		Alb.set("")
		Bgr.set("")
		Bu.set("")
		Sc.set("")
		Sod.set("")
		Pot.set("")
		Hemo.set("")
		
		#=============
		# main layout
		#=============
		Tops = Frame(self, width=1366, height=40, bd=1,relief=RIDGE)
		Tops.pack(side=TOP)
		
		lblInfo=Label(Tops, font=('arial',20,'bold'),bg='yellow',fg='black',text ="Chronic Kidney Disease Prediction", bd=5,anchor='w')
		lblInfo.grid(row=0,column=0)
		
		fs1 = Frame(self,width=150, height=0, bd=1,relief='flat')
		fs1.pack(side=LEFT)
		
		f1 = Frame(self, width=600, height=600, bd=8,relief='raise')
		f1.pack(side=LEFT)
		
		f2 = Frame(self, width=366, height=600, bd=8,relief='raise')
		f2.pack(side=LEFT)
		
		#for description
		f3 = Frame(f2, width=1000, height=320, bd=8,relief=FLAT)
		f3.pack(side=BOTTOM)
		
		f2ab = Frame(f2, width=366, height=300,bd=8,relief='raise')
		f2ab.pack(side=BOTTOM)
		
		f2a = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2a.pack(side=BOTTOM)
		
		f2aa = Frame(f2, width=366, height=250,bd=8,relief='raise')
		f2aa.pack(side=BOTTOM)
		
		#===============
		# some displays
		#===============
		text = 'NOTE:\nAccuracy of prediction: 87.5%\n'
		lbldetails = Label(f3,font=('Courier',12),text=text,bd=16,justify='left')
		lbldetails.grid(row=0,column=0)
		
		#============
		#  Inputs
		#=============
		lblAge = Label(f1,font=('arial',16,'bold'),text='Age (years)',bd=16,justify='left')
		lblAge.grid(row=0,column=0) 
		txtAge=Entry(f1,font=('arial',16,'bold'),textvariable=Age,bd=10,insertwidth=2,justify='left')
		txtAge.grid(row=0,column=1)
		
		lblBP = Label(f1,font=('arial',16,'bold'),text='Blood pressure (mm/Hg)',bd=16,justify='left')
		lblBP.grid(row=1,column=0)
		txtBP=Entry(f1,font=('arial',16,'bold'),textvariable=BP,bd=10,insertwidth=2,justify='left')
		txtBP.grid(row=1,column=1)
		
		lblSG = Label(f1,font=('arial',16,'bold'),text='Specific gravity (nominal)',bd=16,justify='left')
		lblSG.grid(row=2,column=0)
		txtSG=Entry(f1,font=('arial',16,'bold'),textvariable=SG,bd=10,insertwidth=2,justify='left')
		txtSG.grid(row=2,column=1)
		
		lblAlb = Label(f1,font=('arial',16,'bold'),text='Albumin (nominal)',bd=16,justify='left')
		lblAlb.grid(row=3,column=0)
		txtAlb=Entry(f1,font=('arial',16,'bold'),textvariable=Alb,bd=10,insertwidth=2,justify='left')
		txtAlb.grid(row=3,column=1)
		
		lblBgr = Label(f1,font=('arial',16,'bold'),text='Blood glucose random (mgs/dl)',bd=16,justify='left')
		lblBgr.grid(row=4,column=0)
		txtBgr=Entry(f1,font=('arial',16,'bold'),textvariable=Bgr,bd=10,insertwidth=2,justify='left')
		txtBgr.grid(row=4,column=1)
		
		lblBu = Label(f1,font=('arial',16,'bold'),text='Blood urea (mgs/dl)',bd=16,justify='left')
		lblBu.grid(row=5,column=0)
		txtBu=Entry(f1,font=('arial',16,'bold'),textvariable=Bu,bd=10,insertwidth=2,justify='left')
		txtBu.grid(row=5,column=1)
		
		lblSc = Label(f1,font=('arial',16,'bold'),text='Serum creatinine (mgs/dl)',bd=16,justify='left')
		lblSc.grid(row=6,column=0)
		txtSc=Entry(f1,font=('arial',16,'bold'),textvariable=Sc,bd=10,insertwidth=2,justify='left')
		txtSc.grid(row=6,column=1)
		
		lblSod = Label(f1,font=('arial',16,'bold'),text='Sodium (mEq/L)',bd=16,justify='left')
		lblSod.grid(row=7,column=0)
		txtSod=Entry(f1,font=('arial',16,'bold'),textvariable=Sod,bd=10,insertwidth=2,justify='left')
		txtSod.grid(row=7,column=1)
		
		lblPot = Label(f1,font=('arial',16,'bold'),text='Potassium (mEq/L)',bd=16,justify='left')
		lblPot.grid(row=8,column=0)
		txtPot=Entry(f1,font=('arial',16,'bold'),textvariable=Pot,bd=10,insertwidth=2,justify='left')
		txtPot.grid(row=8,column=1)
		
		lblHemo = Label(f1,font=('arial',16,'bold'),text='Hemo (gms)',bd=16,justify='left')
		lblHemo.grid(row=9,column=0)
		txtHemo=Entry(f1,font=('arial',16,'bold'),textvariable=Hemo,bd=10,insertwidth=2,justify='left')
		txtHemo.grid(row=9,column=1)
		
		#================
		#    Outputs
		#================
		Result = StringVar()
		lblResult = Label(f2a,font=('arial',16,'bold'),text='Result',bd=16,anchor='w')
		lblResult.grid(row=0,column=0)
		txtResult=Entry(f2a,font=('arial',16,'bold'),textvariable=Result,bd=10,insertwidth=2,justify='left')
		txtResult.grid(row=0,column=1)
		
		def getData():
			alist = []
			Age_data = int(Age.get())
			alist.append(Age_data)
			BP_data = int(BP.get())
			alist.append(BP_data)
			SG_data = int(SG.get())
			alist.append(SG_data)
			Alb_data = int(Alb.get())
			alist.append(Alb_data)
			Bgr_data = int(Bgr.get())
			alist.append(Bgr_data)
			Bu_data = int(Bu.get())
			alist.append(Bu_data)
			Sc_data = int(Sc.get())
			alist.append(Sc_data)
			Sod_data = int(Sod.get())
			alist.append(Sod_data)
			Pot_data = int(Pot.get())
			alist.append(Pot_data)
			Hemo_data = int(Hemo.get())
			alist.append(Hemo_data)
			return alist
		
		def printResult():
			try:
				x_in=getData()
			except ValueError:
				Result.set('Insufficient Data!')
			else:
				x_in = np.reshape(getData(),(1,10))
				result = loaded_model4.predict(x_in)
				result = result[0]
				if result == 1.0:
					Result.set('CKD')
				else:
					Result.set('Not CKD')
					
		def Reset():
			Age.set("")
			BP.set("")
			SG.set("")
			Alb.set("")
			Bgr.set("")
			Bu.set("")
			Sc.set("")
			Sod.set("")
			Pot.set("")
			Hemo.set("")
			Result.set("")
		
		btnTotal=Button(f2aa,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Predict', command = printResult).grid(row=0,column=0)
		btnReset=Button(f2ab,padx=16,pady=16,bd=8,fg='black',font=('arial',16,'bold'),width=15,text='Reset', command = Reset).grid(row=0,column=0)

class Page5(Page):
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs)
		label = Label(self, text="This is the page 5")
		label.pack(side=TOP, fill='both', expand=True)

class MainView(Frame):
	def __init__(self, *args, **kwargs):
		Frame.__init__(self, *args, **kwargs)
		p1 = Page1(self)
		p2 = Page2(self)
		p3 = Page3(self)
		p4 = Page4(self)
		p5 = Page5(self)
		
		buttonframe = Frame(self)
		container = Frame(self)
		buttonframe.pack(side=TOP, fill=X, expand = False)
		container.pack(side=TOP, fill='both', expand=True)
		
		p1.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
		p2.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
		p3.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
		p4.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
		p5.place(in_=container, x=0, y=0, relwidth=1, relheight=1)
		
		b1 = Button(buttonframe, text="Breast Cancer", command=p1.lift)
		b2 = Button(buttonframe, text="Heart Disease", command=p2.lift)
		b3 = Button(buttonframe, text="Erythemato-squamous", command=p3.lift)
		b4 = Button(buttonframe, text="Chronic Kidney Disease", command=p4.lift)
		b5 = Button(buttonframe, text="Page 5", command=p5.lift)
		
		b1.pack(side=LEFT)
		b2.pack(side=LEFT)
		b3.pack(side=LEFT)
		b4.pack(side=LEFT)
		b5.pack(side=LEFT)
		
		p1.show()

if __name__ == "__main__":
	root = Tk()
	main = MainView(root)
	root.title("Disease Prediction Tools")
	main.pack(side=TOP,fill='both',expand=True)
	root.wm_geometry('1366x768')
	root.mainloop()
