import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.model_selection import train_test_split

from sklearn.metrics import accuracy_score
from math import*

import pandas as pd

filename = 'data/ckd.csv'

df = pd.read_csv(filename,header=None,error_bad_lines=False)
new_df = df.replace({
        "?": np.nan
    })
new_df = new_df.dropna()
dft = new_df.rename(columns={0: 'age', 1:'bp', 2:'sg', 3:'albumin', 9:'bgr', 10:'bu',11:'sc',12:'sod',13:'pot',14:'hemo',24:'class'})
dft=dft.replace(['ckd', 'notckd'], [1,0])
print(dft.head())
dfx = dft[['age','bp','sg','albumin','bgr','bu','sc','sod','pot','hemo']]
dfy = dft[['class']]

#~ from sklearn.utils import shuffle
#~ dfx1 = shuffle(dfx)
#~ dfy1 = shuffle(dfy)

dfx1 = dfx
dfy1 = dfy

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(dfx1, dfy1, test_size=0.30, random_state=13)

from sklearn.neighbors import KNeighborsClassifier
clf = KNeighborsClassifier(n_neighbors = 25, weights='uniform', algorithm='auto')
clf.fit(x_train,y_train.values.ravel())
result = clf.predict(x_test)
print(accuracy_score(y_test,result)*100)

import pickle
filename = 'ckd.sav'
pickle.dump(clf, open(filename, 'wb'))
