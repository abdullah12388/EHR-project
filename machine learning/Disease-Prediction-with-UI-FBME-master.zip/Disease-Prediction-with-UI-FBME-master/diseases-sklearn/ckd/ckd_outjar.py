import pickle
filename = 'ckd.sav'
loaded_model4 = pickle.load(open(filename,'rb'))

