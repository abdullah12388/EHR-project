#http://dataaspirant.com/2016/12/30/k-nearest-neighbor-implementation-scikit-learn/
import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from math import*
 
cancer_data = np.genfromtxt(
 fname ='data/dermatology.data', delimiter= ',', dtype= int)


print("Dataset Length:: ", len(cancer_data))
print("Dataset:: ", str(cancer_data))
print("Dataset Shape:: ", cancer_data.shape)

#separate which columns are features, which cols are labels
X = cancer_data[:, range(0,11)]
#Y is class: 2 for benign, 4 for malignant
Y = cancer_data[:, 34]
age_col = cancer_data[:,33]
m = Y.size
X = np.hstack((X,age_col.reshape(m,1)))
print("X is:: ", str(X))
print("age is", str(age_col))
#~ print("Y is:: ", str(Y))

#some columns have missing values, we can replace with some particular value
imp = Imputer(missing_values="NaN", strategy = 'median', axis=0)
X = imp.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
 X, Y, test_size = 0.3, random_state = 100)
y_train = y_train.ravel()
y_test = y_test.ravel()

#~ from sklearn.naive_bayes import GaussianNB
#~ clf = GaussianNB()
#~ clf.fit(X_train,y_train)
#~ result2 = clf.predict(X_test)
#~ print(accuracy_score(y_test,result2)*100)

#~ k_list = []
#~ y_plist = []
#~ for K in range(25):
 #~ K_value = K+1
 #~ neigh = KNeighborsClassifier(n_neighbors = K_value, weights='uniform', algorithm='auto')
 #~ neigh.fit(X_train, y_train) 
 #~ y_pred = neigh.predict(X_test)
 #~ print ("Accuracy is ", accuracy_score(y_test,y_pred)*100,"% for K-Value:",K_value)
 #~ k_list.append(K_value)
 #~ y_plist.append(accuracy_score(y_test,y_pred)*100)


from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(n_estimators=150, oob_score=True,random_state=123456)
rf.fit(X_train,y_train)
result = rf.predict(X_test)
print(accuracy_score(y_test,result)*100)

#~ import pickle
#~ filename = 'dermatology.sav'
#~ pickle.dump(rf, open(filename, 'wb'))
