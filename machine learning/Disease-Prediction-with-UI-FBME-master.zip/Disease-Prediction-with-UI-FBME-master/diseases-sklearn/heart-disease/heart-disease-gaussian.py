import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.model_selection import train_test_split

from sklearn.metrics import accuracy_score
from math import*
data = np.genfromtxt(
 fname ='data/processed.cleveland1.data', delimiter= ',', dtype= float)

X = data[:, range(0,13)] 
Y = data[:, 13]
imp = Imputer(missing_values="NaN", strategy = 'median', axis=0)
X = imp.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
 X, Y, test_size = 0.15, random_state = 100)
y_train = y_train.ravel()
y_test = y_test.ravel()

from sklearn.naive_bayes import GaussianNB
clf = GaussianNB()
clf.fit(X_train,y_train)
result2 = clf.predict(X_test)
print(accuracy_score(y_test,result2)*100)

import pickle
filename = 'heart-disease.sav'
pickle.dump(clf, open(filename, 'wb'))
