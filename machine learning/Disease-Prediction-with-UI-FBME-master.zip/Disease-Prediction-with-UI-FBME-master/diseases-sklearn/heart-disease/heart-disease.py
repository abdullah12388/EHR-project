#import the Cleveland heart patient data file using pandas, creating a header row
#since file doesn't have column names
#~ import pandas as pnd
#~ header_row = ['age','sex','pain','BP','chol','fbs','ecg','maxhr','eiang','eist','slope','vessels','thal','diagnosis']
#~ heart = pnd.read_csv('data/processed.cleveland.data', names=header_row)

#~ #import and modify VA dataset for testing
#~ heart_va = pnd.read_csv('data/processed.va.data', names=header_row)
#~ has_hd_check = heart_va['diagnosis'] > 0
#~ heart_va['diag_int'] = has_hd_check.astype(int)
import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.model_selection import train_test_split

from sklearn.metrics import accuracy_score
from math import*
data = np.genfromtxt(
 fname ='data/processed.cleveland1.data', delimiter= ',', dtype= float)

X = data[:, range(0,13)] 
Y = data[:, 13]
#~ print("X is " + str(X))
#~ print("Y is " + str(Y))
imp = Imputer(missing_values="NaN", strategy = 'median', axis=0)
X = imp.fit_transform(X)


X_train, X_test, y_train, y_test = train_test_split(
 X, Y, test_size = 0.15, random_state = 100)
y_train = y_train.ravel()
y_test = y_test.ravel()

#classification with scikit-learn decision tree
from sklearn import tree
clf2 = tree.DecisionTreeClassifier()
clf2.fit(X_train, y_train)
#~ print("asdf"+str(X_test))
heart_test_results = clf2.predict(X_test)
#~ print(heart_test_results)
#~ print(accuracy_score(y_test,heart_test_results)*100)

#classification with scikit-learn KNN
#~ k_list = []
#~ y_plist = []
#~ from sklearn.neighbors import KNeighborsClassifier
#~ for K in range(25):
 #~ K_value = K+1
 #~ neigh = KNeighborsClassifier(n_neighbors = K_value, weights='uniform', algorithm='auto')
 #~ neigh.fit(X_train, y_train) 
 #~ y_pred = neigh.predict(X_test)
 #~ print ("Accuracy is ", accuracy_score(y_test,y_pred)*100,"% for K-Value:",K_value)
 #~ k_list.append(K_value)
 #~ y_plist.append(accuracy_score(y_test,y_pred)*100)

#~ from sklearn.ensemble import RandomForestClassifier
#~ rf = RandomForestClassifier(n_estimators=150, oob_score=True,random_state=123456)
#~ rf.fit(X_train,y_train)
#~ result = rf.predict(X_test)
#~ print(accuracy_score(y_test,result))

from sklearn.naive_bayes import GaussianNB
clf = GaussianNB()
clf.fit(X_train,y_train)
result2 = clf.predict(X_test)
print(accuracy_score(y_test,result2)*100)

#~ from sklearn.ensemble import ExtraTreesClassifier
#~ rf1 = ExtraTreesClassifier()
#~ rf1.fit(X_train,y_train)
#~ result = rf1.predict(X_test)
#~ print(accuracy_score(y_test,result))
